/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main_DW1000Ranging_ANCHOR.c
  * @brief          : DW1000 Simple Two-Way Ranging - ANCHOR role
  *                    NUCLEO-G070RB
  ******************************************************************************
  * Pin map (per user wiring):
  *   DWM1000 SPICLK  (pin 20) -> PA5  (D13, SPI1_SCK)
  *   DWM1000 SPIMISO (pin 19) -> PA6  (D12, SPI1_MISO)
  *   DWM1000 SPIMOSI (pin 18) -> PA7  (D11, SPI1_MOSI)
  *   DWM1000 SPICSn  (pin 17) -> PB0  (D10, SS / Chip Select, manual GPIO)
  *   DWM1000 IRQ     (pin 22) -> PA9  (D8, input, polled)
  *   DWM1000 RSTn    (pin 3)  -> PA8  (D7, output, active low reset)
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dw1000.h"
#include "dw1000_stm32.h"
#include "dw1000_time.h"
#include <string.h>
#include <stdio.h>

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;
UART_HandleTypeDef huart2;

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART2_UART_Init(void);

/* USER CODE BEGIN PFP */
static void DW1000_HardReset(dw1000_HandleTypeDef *dw1000);
static dw1000_timestamp_t dw1000_GetTxTimestamp(dw1000_HandleTypeDef *dw1000);
static dw1000_timestamp_t dw1000_GetRxTimestamp(dw1000_HandleTypeDef *dw1000);
static void UART_Print(const char *str);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/*
 * Simple Two-Way Ranging (SS-TWR) frame definitions
 *
 * Frame format (application payload, no MAC header used here for simplicity):
 *   byte[0] = function code
 *   byte[1..] = payload
 *
 * Function codes:
 *   0x10 = POLL      (Anchor -> Tag)        -- not used in this simple scheme
 *   0x20 = POLL      (Tag -> Anchor)
 *   0x21 = RESPONSE  (Anchor -> Tag)        -- carries t_reply (anchor turnaround time)
 *   0x22 = FINAL     (Tag -> Anchor)        -- carries t_round (tag round trip time)
 *   0x30 = RANGE_REPORT (Anchor -> Tag)     -- carries computed distance (not required by tag)
 */
#define FC_POLL       0x20
#define FC_RESPONSE   0x21
#define FC_FINAL      0x22

#define DW1000_SS_PIN   GPIO_PIN_0   // PB0  (D10) - SPI CS, software controlled
#define DW1000_SS_PORT  GPIOB

#define DW1000_RST_PIN  GPIO_PIN_8   // PA8 (D7) - RSTn
#define DW1000_RST_PORT GPIOA

#define DW1000_IRQ_PIN  GPIO_PIN_9   // PA9 (D8) - IRQ, polled as input
#define DW1000_IRQ_PORT GPIOA

static dw1000_HandleTypeDef dw1000;

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  uint8_t rx_buf[16];
  uint8_t tx_buf[16];
  char msg[200];

  dw1000_timestamp_t t_poll_rx = 0;
  dw1000_timestamp_t t_resp_tx = 0;
  dw1000_timestamp_t t_reply_prev = 0; // anchor reply time from PREVIOUS cycle
  dw1000_timestamp_t t_round = 0;      // t_round for PREVIOUS cycle, arrives in THIS cycle's FINAL
  uint8_t have_prev_reply = 0;

  uint8_t frame_received;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_USART2_UART_Init();

  /* USER CODE BEGIN 2 */

  /* Fill in DW1000 handle with SPI bus + CS pin (per user wiring) */
  dw1000.spi    = &hspi1;
  dw1000.ss_port = DW1000_SS_PORT;
  dw1000.ss_pin  = DW1000_SS_PIN;

  /* Hold CS idle high */
  HAL_GPIO_WritePin(DW1000_SS_PORT, DW1000_SS_PIN, GPIO_PIN_SET);

  /* Hardware reset the DW1000 */
  DW1000_HardReset(&dw1000);

  /* Read device ID to confirm SPI link is alive */
  dw1000_dev_id_t dev_id = dw1000_GetDevID(&dw1000);
  sprintf(msg, "\r\n[ANCHOR] DEV_ID model=0x%02X ver=%u rev=%u ridtag=0x%04X\r\n",
          dev_id.model, dev_id.ver, dev_id.rev, dev_id.ridtag);
  UART_Print(msg);

  /* Configure PAN ID / short address (anchor = 0x0001) */
  dw1000_pan_addr_t pan_addr;
  pan_addr.pan_id    = 0xDECA;
  pan_addr.short_addr = 0x0001;
  dw1000_SetPanAddress(&dw1000, &pan_addr);

  /* Set channel configuration (Channel 5, 16 MHz PRF, default preamble) */
  dw1000_channel_t chan;
  chan.tx_chan     = 5;
  chan.rx_chan     = 5;
  chan.prf         = DW1000_PRF_16MHZ;
  chan.tx_preamble = 0x4; // 1024 symbols code
  chan.rx_preamble = 0x4;
  dw1000_SetChannel(&dw1000, &chan);

  /* Run the full AGC/DRX/RF/LDE tuning sequence required by the DW1000
   * User Manual for reliable RX operation on channel 5, 16 MHz PRF,
   * 110 kbps (matches the data rate implied by use_crc/length-only
   * dw1000_StartTransmit calls and the 1024-symbol preamble above). */
  uint8_t init_ok = dw1000_Init(&dw1000, 5, DW1000_PRF_16MHZ, DW1000_TX_FCTRL_TXBR_110K);
  sprintf(msg, "[ANCHOR] dw1000_Init() %s\r\n", init_ok ? "OK" : "FAILED (readback mismatch)");
  UART_Print(msg);

  /* Diagnostic readback: confirm AGC_TUNE1 and LDE_CFG1 took effect */
  uint16_t agc_tune1_rb = dw1000_ReadSubReg16(&dw1000, DW1000_AGC_CTRL, DW1000_AGC_TUNE1_SUB);
  uint8_t lde_cfg1_rb = dw1000_ReadSubReg8(&dw1000, DW1000_LDE_CTRL, DW1000_LDE_CFG1_SUB);
  uint32_t drx_tune2_rb = dw1000_ReadSubReg32(&dw1000, DW1000_DRX_CONF, DW1000_DRX_TUNE2_SUB);
  sprintf(msg, "[ANCHOR] AGC_TUNE1=0x%04X (exp 0x8870) LDE_CFG1=0x%02X (exp 0x6D) DRX_TUNE2=0x%08lX (exp 0x311A002D)\r\n",
          agc_tune1_rb, lde_cfg1_rb, (unsigned long)drx_tune2_rb);
  UART_Print(msg);

  /* Verify channel/PAN config took effect */
  dw1000_pan_addr_t pan_rb = dw1000_GetPanAddress(&dw1000);
  dw1000_channel_t chan_rb = dw1000_GetChannel(&dw1000);
  sprintf(msg, "[ANCHOR] PANID=0x%04X SHORTADDR=0x%04X CHAN tx=%u rx=%u prf=%u txpre=%u rxpre=%u\r\n",
          pan_rb.pan_id, pan_rb.short_addr, chan_rb.tx_chan, chan_rb.rx_chan,
          chan_rb.prf, chan_rb.tx_preamble, chan_rb.rx_preamble);
  UART_Print(msg);

  /* Clear any pending status flags before starting */
  dw1000_ClearAllStatus(&dw1000);

  UART_Print("[ANCHOR] Initialized. Listening for ranging frames...\r\n");

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* ---- Step 1: Wait for POLL from Tag ---------------------------------- */
    dw1000_ClearReceiveStatus(&dw1000);
    dw1000_StartReceive(&dw1000, 1);

    frame_received = 0;
    /* Poll RX status register until a frame is received (with simple timeout) */
    for (uint32_t i = 0; i < 2000000; i++)
    {
      if (dw1000_ReceiveDataFrameReady(&dw1000))
      {
        frame_received = 1;
        break;
      }
    }

    if (!frame_received)
    {
      /* Diagnostic dump on timeout: SYS_STATUS, SYS_STATE, and any RX
       * error flags help distinguish "nothing arriving" from
       * "something arriving but rejected" (PHY header error, FCS/CRC
       * error, reed-solomon/SFD timeout, LDE error, etc). */
      uint8_t sys_status[DW1000_SYS_STATUS_LEN];
      dw1000_GetSystemStatus(&dw1000, sys_status);
      uint32_t sys_state = dw1000_GetSystemState(&dw1000);

      uint8_t rxphe  = dw1000_IsSet(sys_status, DW1000_SYS_STATUS_RXPHE);
      uint8_t rxfce  = dw1000_IsSet(sys_status, DW1000_SYS_STATUS_RXFCE);
      uint8_t rxrfsl = dw1000_IsSet(sys_status, DW1000_SYS_STATUS_RXRFSL);
      uint8_t ldeerr = dw1000_IsSet(sys_status, DW1000_SYS_STATUS_LDEERR);
      uint8_t rxsfdto = dw1000_IsSet(sys_status, DW1000_SYS_STATUS_RXSFDTO);
      uint8_t rxprd  = dw1000_IsSet(sys_status, DW1000_SYS_STATUS_RXPRD);
      uint8_t rxsfdd = dw1000_IsSet(sys_status, DW1000_SYS_STATUS_RXSFDD);
      uint8_t cplock = dw1000_IsSet(sys_status, DW1000_SYS_STATUS_CPLOCK);

      sprintf(msg, "[ANCHOR] RX timeout. SYS_STATUS=%02X%02X%02X%02X%02X SYS_STATE=0x%06lX "
                    "CPLOCK=%u RXPRD=%u RXSFDD=%u RXPHE=%u RXFCE=%u RXRFSL=%u LDEERR=%u RXSFDTO=%u\r\n",
              sys_status[4], sys_status[3], sys_status[2], sys_status[1], sys_status[0],
              (unsigned long)sys_state, cplock, rxprd, rxsfdd, rxphe, rxfce, rxrfsl, ldeerr, rxsfdto);
      UART_Print(msg);

      /* No frame this cycle - try again */
      continue;
    }

    uint16_t len = dw1000_GetDataReceivedLength(&dw1000, 1);
    if (len == 0 || len > sizeof(rx_buf))
    {
      sprintf(msg, "[ANCHOR] RX frame ready but length invalid: %u\r\n", len);
      UART_Print(msg);
      dw1000_ClearReceiveStatus(&dw1000);
      continue;
    }

    dw1000_GetDataReceived(&dw1000, rx_buf, len);
    dw1000_ClearReceiveStatus(&dw1000);

    sprintf(msg, "[ANCHOR] RX frame: len=%u fc=0x%02X\r\n", len, rx_buf[0]);
    UART_Print(msg);

    if (rx_buf[0] != FC_POLL)
    {
      /* Not the frame we expected, ignore and go back to listening */
      UART_Print("[ANCHOR] Unexpected frame type, expected POLL\r\n");
      continue;
    }

    /* Capture timestamp of POLL reception */
    t_poll_rx = dw1000_GetRxTimestamp(&dw1000);

    /* ---- Step 2: Send RESPONSE back to Tag -------------------------------- */
    tx_buf[0] = FC_RESPONSE;
    dw1000_SetDataToTransmit(&dw1000, tx_buf, 1, 1);
    dw1000_ClearTransmitStatus(&dw1000);
    dw1000_StartTransmit(&dw1000, 1, 1);

    /* Wait for transmission complete */
    uint8_t sent = 0;
    for (uint32_t i = 0; i < 2000000; i++)
    {
      uint8_t sys_status[DW1000_SYS_STATUS_LEN];
      dw1000_ReadData(&dw1000, DW1000_SYS_STATUS, sys_status, DW1000_SYS_STATUS_LEN);
      if (dw1000_IsSet(sys_status, DW1000_SYS_STATUS_TXFRS))
      {
        sent = 1;
        break;
      }
    }

    if (!sent)
    {
      UART_Print("[ANCHOR] RESPONSE TX timeout (TXFRS never set)\r\n");
      continue;
    }

    t_resp_tx = dw1000_GetTxTimestamp(&dw1000);
    dw1000_ClearTransmitStatus(&dw1000);

    dw1000_timestamp_t t_reply_this = t_resp_tx - t_poll_rx;

    sprintf(msg, "[ANCHOR] RESPONSE sent. t_poll_rx=%llu t_resp_tx=%llu t_reply=%llu\r\n",
            (unsigned long long)t_poll_rx, (unsigned long long)t_resp_tx,
            (unsigned long long)t_reply_this);
    UART_Print(msg);

    /* ---- Step 3: Wait for FINAL from Tag (contains t_round) --------------- */
    dw1000_ClearReceiveStatus(&dw1000);
    dw1000_StartReceive(&dw1000, 1);

    frame_received = 0;
    for (uint32_t i = 0; i < 2000000; i++)
    {
      if (dw1000_ReceiveDataFrameReady(&dw1000))
      {
        frame_received = 1;
        break;
      }
    }

    if (!frame_received)
    {
      UART_Print("[ANCHOR] FINAL RX timeout\r\n");
      /* Still save this cycle's reply time; if the tag's piggybacked
       * FINAL is merely delayed it will be paired on a later cycle's
       * t_reply_prev only if we keep this value, but since the pairing
       * is strictly cycle-to-cycle we drop it here to avoid stale
       * pairing with a much later FINAL. */
      continue;
    }

    len = dw1000_GetDataReceivedLength(&dw1000, 1);
    if (len < 6 || len > sizeof(rx_buf))
    {
      sprintf(msg, "[ANCHOR] FINAL frame length invalid: %u\r\n", len);
      UART_Print(msg);
      dw1000_ClearReceiveStatus(&dw1000);
      continue;
    }

    dw1000_GetDataReceived(&dw1000, rx_buf, len);
    dw1000_ClearReceiveStatus(&dw1000);

    sprintf(msg, "[ANCHOR] RX frame: len=%u fc=0x%02X\r\n", len, rx_buf[0]);
    UART_Print(msg);

    if (rx_buf[0] != FC_FINAL)
    {
      UART_Print("[ANCHOR] Unexpected frame type, expected FINAL\r\n");
      have_prev_reply = 1;
      t_reply_prev = t_reply_this;
      continue;
    }

    /* t_round (40-bit) packed little-endian in bytes [1..5] of FINAL payload.
     * This is the PREVIOUS cycle's t_round, sent piggy-backed by the tag. */
    t_round = 0;
    for (int b = 0; b < 5; b++)
    {
      t_round |= ((dw1000_timestamp_t)rx_buf[1 + b]) << (8 * b);
    }

    /* ---- Step 4: Compute distance for the PREVIOUS cycle -------------------
     *
     * Symmetric SS-TWR:
     *   t_round  = t_final_tx_tag(prev) - t_poll_tx_tag(prev)
     *   t_reply  = t_resp_tx_anchor(prev) - t_poll_rx_anchor(prev)
     *
     * Time of flight:
     *   tof = (t_round - t_reply) / 2
     */
    if (have_prev_reply && t_round != 0)
    {
      dw1000_timestamp_t tof_raw = (t_round - t_reply_prev) / 2;
      double tof_us = DW1000_Time_TimestampToMicroseconds(tof_raw);
      double distance_m = DW1000_Time_TimestampToMeters(tof_raw);

      sprintf(msg, "[ANCHOR] t_round=%llu t_reply_prev=%llu ToF=%.4f us  Distance=%.3f m\r\n",
              (unsigned long long)t_round, (unsigned long long)t_reply_prev, tof_us, distance_m);
      UART_Print(msg);
    }
    else
    {
      UART_Print("[ANCHOR] FINAL received but t_round=0 (first cycle) - skipping distance calc\r\n");
    }

    /* Save this cycle's reply time for pairing with the NEXT FINAL frame */
    have_prev_reply = 1;
    t_reply_prev = t_reply_this;

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/* USER CODE BEGIN 4 */

static void UART_Print(const char *str)
{
  HAL_UART_Transmit(&huart2, (uint8_t *)str, (uint16_t)strlen(str), HAL_MAX_DELAY);
}

/* Hardware reset sequence for DW1000 RSTn (active low, open drain pin recommended) */
static void DW1000_HardReset(dw1000_HandleTypeDef *dw1000)
{
  (void)dw1000;
  HAL_GPIO_WritePin(DW1000_RST_PORT, DW1000_RST_PIN, GPIO_PIN_RESET);
  HAL_Delay(2);
  HAL_GPIO_WritePin(DW1000_RST_PORT, DW1000_RST_PIN, GPIO_PIN_SET);
  HAL_Delay(5);
}

/* Read 40-bit TX timestamp from TX_TIME register (offset 0 = TX_STAMP) */
static dw1000_timestamp_t dw1000_GetTxTimestamp(dw1000_HandleTypeDef *dw1000)
{
  uint8_t buffer[5];
  dw1000_ReadData(dw1000, DW1000_TX_TIME, buffer, 5);
  return ((dw1000_timestamp_t)buffer[4] << 32) | ((dw1000_timestamp_t)buffer[3] << 24) |
         ((dw1000_timestamp_t)buffer[2] << 16) | ((dw1000_timestamp_t)buffer[1] << 8)  |
          (dw1000_timestamp_t)buffer[0];
}

/* Read 40-bit RX timestamp from RX_TIME register (offset 0 = RX_STAMP) */
static dw1000_timestamp_t dw1000_GetRxTimestamp(dw1000_HandleTypeDef *dw1000)
{
  uint8_t buffer[5];
  dw1000_ReadData(dw1000, DW1000_RX_TIME, buffer, 5);
  return ((dw1000_timestamp_t)buffer[4] << 32) | ((dw1000_timestamp_t)buffer[3] << 24) |
         ((dw1000_timestamp_t)buffer[2] << 16) | ((dw1000_timestamp_t)buffer[1] << 8)  |
          (dw1000_timestamp_t)buffer[0];
}

/* USER CODE END 4 */

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
  RCC_OscInitStruct.PLL.PLLN = 8;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                              | RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  *
  * PB0  (D10) -> DW1000 SPI CS (SPICSn), output, idle HIGH
  * PA8  (D7)  -> DW1000 RSTn,            output, idle HIGH (not asserted)
  * PA9  (D8)  -> DW1000 IRQ,             input (polled, not configured as EXTI here)
  * PA5/PA6/PA7 are configured by HAL_SPI_Init via MX_SPI1_Init (alternate function)
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* Set CS (PB0) idle HIGH before configuring as output to avoid a glitch */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);

  /* Set RST (PA8) idle HIGH (DW1000 not in reset) */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET);

  /* Configure GPIO pin : PB0 (SPI CS, manual control) */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* Configure GPIO pin : PA8 (RSTn) */
  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* Configure GPIO pin : PA9 (IRQ, input) */
  GPIO_InitStruct.Pin = GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file;
  (void)line;
}
#endif /* USE_FULL_ASSERT */
